#include <iostream>

using namespace std;

int main(){
	
	float luas, phi=3.14;
	int r;
	
	cout<<"masukkan jari-jari : ";
	cin>>r;
	
	luas=phi*r*r;
	
	cout<<"luas lingkaran = "<<luas<<endl;
	
		
}
